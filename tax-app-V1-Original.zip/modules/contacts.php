<?php session_start(); require_once '../config/db.php'; $cid=$_SESSION['company_id']; $type=$_GET['type']??'BUYER'; $search=$_GET['search']??''; $error='';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $chk=$pdo->prepare("SELECT id FROM contacts WHERE tax_id=? AND branch_code=? AND company_id=? AND type=? AND id!=?");
    $chk->execute([$_POST['tax_id'],$_POST['branch'],$cid,$type,$_POST['contact_id']??0]);
    if($chk->fetch()){ $error="ข้อมูลซ้ำ!"; } else {
        if(!empty($_POST['contact_id'])){ $pdo->prepare("UPDATE contacts SET name=?,tax_id=?,branch_code=?,address=? WHERE id=? AND company_id=?")->execute([$_POST['name'],$_POST['tax_id'],$_POST['branch'],$_POST['address'],$_POST['contact_id'],$cid]); }
        else { $pdo->prepare("INSERT INTO contacts (company_id,type,name,tax_id,branch_code,address) VALUES (?,?,?,?,?,?)")->execute([$cid,$type,$_POST['name'],$_POST['tax_id'],$_POST['branch'],$_POST['address']]); }
        header("Location: contacts.php?type=$type&success=1"); exit();
    }
}
$stmt=$pdo->prepare("SELECT * FROM contacts WHERE company_id=? AND type=? AND (name LIKE ? OR tax_id LIKE ?) ORDER BY name ASC");
$stmt->execute([$cid,$type,"%$search%","%$search%"]); $contacts=$stmt->fetchAll(); ?>
<!DOCTYPE html>
<html lang="th"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script><script src="https://cdn.jsdelivr.net"></script><title>Contacts</title></head>
<body class="flex bg-slate-50 min-h-screen"><?php include '../includes/sidebar.php'; ?>
<main class="flex-1 p-8">
    <h1 class="text-2xl font-bold mb-6">จัดการ<?php echo $type == 'BUYER' ? 'ผู้ซื้อ' : 'ผู้ขาย'; ?></h1>
    <form method="GET" class="mb-4 flex gap-2"><input type="hidden" name="type" value="<?=$type?>"><input type="text" name="search" value="<?=$search?>" placeholder="ค้นหาคู่ค้า..." class="border p-3 rounded-xl flex-1"><button class="bg-slate-700 text-white px-6 rounded-xl">ค้นหา</button></form>
    <form method="POST" class="bg-white p-6 rounded-3xl shadow-sm border mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
        <input type="hidden" name="contact_id" id="contact_id">
        <input type="text" name="name" id="name" placeholder="ชื่อคู่ค้า" required class="border p-3 rounded-xl"><input type="text" name="tax_id" id="tax_id" maxlength="13" placeholder="เลขที่ผู้เสียภาษี(13)" required class="border p-3 rounded-xl"><input type="text" name="branch" id="branch" maxlength="5" placeholder="สาขาที่ (5)" required class="border p-3 rounded-xl">
        <input type="text" name="address" id="address" placeholder="ที่อยู่คู่ค้า" class="md:col-span-2 border p-3 rounded-xl"><button class="bg-blue-600 text-white rounded-xl font-bold">บันทึกคู่ค้า</button>
    </form>
    <div class="bg-white rounded-3xl shadow-sm overflow-hidden border"><table class="w-full text-left"><thead class="bg-slate-900 text-white"><tr><th class="p-4">ชื่อคู่ค้า</th><th class="p-4">เลขที่ผู้เสียภาษี  (สาขา)</th><th class="p-4">จัดการ</th></tr></thead>
    <tbody class="p-4"><?php foreach($contacts as $c): ?><tr><td class="p-4 font-bold"><?=$c['name']?></td><td class="p-4"><?=$c['tax_id']?> (<?=$c['branch_code']?>)</td><td class="p-4"><button onclick='editContact(<?=json_encode($c)?>)' class="text-blue-600 mr-4">แก้ไข</button><a href="?type=<?=$type?>&del=<?=$c['id']?>" class="text-red-600">ลบ</a></td></tr><?php endforeach; ?></tbody></table></div>
</main>
<script>
    function editContact(d){document.getElementById('contact_id').value=d.id;document.getElementById('name').value=d.name;document.getElementById('tax_id').value=d.tax_id;document.getElementById('branch').value=d.branch_code;document.getElementById('address').value=d.address;}
    <?php if(isset($_GET['success'])) echo "Swal.fire('สำเร็จ','บันทึกเรียบร้อย','success')"; ?>
    <?php if($error) echo "Swal.fire('ผิดพลาด','$error','error')"; ?>
</script></body></html>
