<?php
session_start();
require_once '../config/db.php';

if(!isset($_SESSION['user_id'])) { header("Location: ../auth/login.php"); exit; }

$cid = $_SESSION['company_id'];
$y = isset($_GET['y']) ? intval($_GET['y']) : intval(date('Y')); 
$edit_data = null;
$edit_invoices = [];

// --- AJAX: ดึงใบกำกับภาษีซื้อมาให้เลือก ---
if (isset($_GET['fetch_inv'])) {
    header('Content-Type: application/json');
    $sid = $_GET['sid'];
    // เปลี่ยนจาก OUTPUT เป็น INPUT เพราะปกติ หัก ณ ที่จ่าย เราจะหักจากยอดที่เราซื้อบริการ/สินค้าครับ
    $st = $pdo->prepare("SELECT tax_invoice_no, tax_date FROM vat_records 
                         WHERE contact_id = ? AND type = 'OUTPUT' AND company_id = ? 
                         AND YEAR(tax_date) = ? ORDER BY tax_date DESC");
    $st->execute([$sid, $cid, $y]);
    echo json_encode($st->fetchAll());
    exit;
}

// --- Action: ลบข้อมูล ---
if (isset($_GET['del_id'])) {
    $pdo->prepare("DELETE FROM wht_records WHERE id = ? AND company_id = ?")->execute([$_GET['del_id'], $cid]);
    header("Location: wht_entry.php?y=$y&success=deleted"); exit();
}

// --- Action: ดึงข้อมูลเพื่อแก้ไข ---
if (isset($_GET['edit_id'])) {
    $st = $pdo->prepare("SELECT * FROM wht_records WHERE id = ? AND company_id = ?");
    $st->execute([$_GET['edit_id'], $cid]);
    $edit_data = $st->fetch();
    if ($edit_data) {
        $edit_invoices = !empty($edit_data['inv_nos']) ? explode(',', $edit_data['inv_nos']) : [];
    }
}

// --- Action: บันทึกข้อมูล ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $inv_nos_str = isset($_POST['inv_nos']) ? implode(',', $_POST['inv_nos']) : '';
    $base_amount = floatval($_POST['base_amount']);
    $wht_amount = floatval($_POST['wht_amount']);
    
    if (!empty($_POST['id'])) {
        $sql = "UPDATE wht_records SET contact_id=?, doc_no=?, doc_date=?, inv_nos=?, base_amount=?, wht_amount=?, type_id=? 
                WHERE id=? AND company_id=?";
        $pdo->prepare($sql)->execute([
            $_POST['contact_id'], $_POST['doc_no'], $_POST['doc_date'], 
            $inv_nos_str, $base_amount, $wht_amount, $_POST['type_id'], $_POST['id'], $cid
        ]);
    } else {
        $sql = "INSERT INTO wht_records (company_id, contact_id, doc_no, doc_date, inv_nos, base_amount, wht_amount, type_id) 
                VALUES (?,?,?,?,?,?,?,?)";
        $pdo->prepare($sql)->execute([
            $cid, $_POST['contact_id'], $_POST['doc_no'], $_POST['doc_date'], 
            $inv_nos_str, $base_amount, $wht_amount, $_POST['type_id']
        ]);
    }
    header("Location: wht_entry.php?y=$y&success=1"); exit();
}

$sellers = $pdo->prepare("SELECT id, name FROM contacts WHERE company_id=? AND type='SELLER' ORDER BY name ASC");
$sellers->execute([$cid]); $seller_list = $sellers->fetchAll();

// ดึงข้อมูลรายการ หัก ณ ที่จ่าย พร้อมชื่อและเลขผู้เสียภาษีของคู่ค้า
$list_st = $pdo->prepare("SELECT w.*, c.name, c.tax_id 
                           FROM wht_records w 
                           JOIN contacts c ON w.contact_id = c.id 
                           WHERE w.company_id = ? AND YEAR(w.doc_date) = ? 
                           ORDER BY w.doc_date DESC, w.id DESC");
$list_st->execute([$cid, $y]); 
$list = $list_st->fetchAll();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>บันทึก หัก ณ ที่จ่าย - <?=$y?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Prompt', sans-serif; }
        .print-only { display: none; }
        @media print {
            @page { size: A4; margin: 1.5cm; }
            .no-print { display: none !important; }
            .print-only { display: block !important; }
            body { background: white; zoom: 70%; }
            main { padding: 0 !important; }
            .report-container { border: none !important; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            table th { background-color: #f3f4f6 !important; color: black !important; -webkit-print-color-adjust: exact; }
            table td, table th { border: 1px solid #000 !important; padding: 10px !important; font-size: 13px; }
        }
    </style>
</head>
<body class="bg-slate-50 flex">
    <div class="no-print">
        <?php include '../includes/sidebar.php'; ?>
    </div>

    <main class="flex-1 p-8">
        <div class="print-only text-center mb-6">
            <h1 class="text-xl font-bold">รายงานสรุปการหักภาษี ณ ที่จ่าย</h1>
            <p>ประจำปี ค.ศ. <?= $y ?></p>
        </div>

        <div class="mb-6 flex justify-between items-center no-print">
            <h1 class="text-2xl font-bold text-slate-800">📝 บันทึก หัก ณ ที่จ่าย (ปี ค.ศ. 
                <select onchange="location.href='?y='+this.value" class="bg-white border rounded px-2 text-blue-600 outline-none cursor-pointer">
                    <?php for($i=date('Y')+1; $i>=date('Y')-5; $i--): ?>
                        <option value="<?=$i?>" <?= $y==$i?'selected':'' ?>><?=$i?></option>
                    <?php endfor; ?>
                </select>)
            </h1>
        </div>

        <form method="POST" class="no-print bg-white p-6 rounded-3xl shadow-sm border grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <input type="hidden" name="id" value="<?= $edit_data['id'] ?? '' ?>">
            <div>
                <label class="block text-sm font-medium mb-1">เลขที่ใบสำคัญ</label>
                <input type="text" name="doc_no" value="<?= $edit_data['doc_no'] ?? '' ?>" required class="w-full border p-2 rounded-xl">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">วันที่จ่าย</label>
                <input type="date" name="doc_date" value="<?= $edit_data['doc_date'] ?? date('Y-m-d') ?>" required class="w-full border p-2 rounded-xl">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">ผู้รับเงิน</label>
                <select name="contact_id" id="seller_id" onchange="fetchInvoices()" required class="w-full border p-2 rounded-xl">
                    <option value="">-- เลือกคู่ค้า --</option>
                    <?php foreach($seller_list as $s): ?>
                        <option value="<?=$s['id']?>" <?= (isset($edit_data['contact_id']) && $edit_data['contact_id']==$s['id']) ? 'selected' : '' ?>><?=$s['name']?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">ประเภทเงินได้</label>
                <select name="type_id" id="type_id" onchange="calculateTax()" class="w-full border p-2 rounded-xl">
                    <option value="1" data-rate="0.03" <?= (isset($edit_data['type_id']) && $edit_data['type_id']==1) ? 'selected' : '' ?>>ค่าบริการ (3%)</option>
                    <option value="2" data-rate="0.03" <?= (isset($edit_data['type_id']) && $edit_data['type_id']==2) ? 'selected' : '' ?>>ค่าจ้าง (3%)</option>
                    <option value="3" data-rate="0.05" <?= (isset($edit_data['type_id']) && $edit_data['type_id']==3) ? 'selected' : '' ?>>ค่าเช่า (5%)</option>
                    <option value="4" data-rate="0.01" <?= (isset($edit_data['type_id']) && $edit_data['type_id']==4) ? 'selected' : '' ?>>ขนส่ง (1%)</option>
                </select>
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium mb-1">ใบกำกับภาษีที่นำมาหัก (เลขที่)</label>
                <div id="selected_inv" class="flex flex-wrap gap-2 border p-2 min-h-[42px] rounded-xl bg-slate-50">
                    <?php foreach($edit_invoices as $inv): ?>
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-lg flex items-center gap-1 text-sm font-semibold">
                            <?= $inv ?> <input type="hidden" name="inv_nos[]" value="<?= $inv ?>">
                            <button type="button" onclick="this.parentElement.remove()" class="text-red-500 ml-1">×</button>
                        </span>
                    <?php endforeach; ?>
                </div>
                <button type="button" onclick="openModal()" class="mt-2 text-blue-600 text-sm font-bold hover:underline">+ เลือกใบกำกับภาษี</button>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1 text-blue-600 font-bold">ยอดจ่าย (ฐานภาษี)</label>
                <input type="number" step="0.01" name="base_amount" id="base_amount" value="<?= $edit_data['base_amount'] ?? '' ?>" oninput="calculateTax()" required class="w-full border p-2 rounded-xl bg-blue-50 focus:ring-2 focus:ring-blue-500 outline-none">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1 text-red-600 font-bold">ภาษีที่หัก (Auto)</label>
                <input type="number" step="0.01" name="wht_amount" id="wht_amount" value="<?= $edit_data['wht_amount'] ?? '' ?>" required class="w-full border p-2 rounded-xl bg-red-50 focus:ring-2 focus:ring-red-500 outline-none">
            </div>
            <div class="md:col-span-4 flex justify-end gap-2 mt-2">
                <?php if($edit_data): ?>
                    <a href="wht_entry.php?y=<?=$y?>" class="bg-slate-200 px-6 py-2 rounded-xl font-bold text-sm">ยกเลิกแก้ไข</a>
                <?php endif; ?>
                <button class="bg-slate-900 text-white px-8 py-2 rounded-xl font-bold hover:bg-black transition-all text-sm">💾 บันทึกข้อมูล</button>
            </div>
        </form>

        <div class="bg-white rounded-3xl shadow-sm overflow-hidden border report-container">
    <table class="w-full text-left">
        <thead class="bg-slate-900 text-white">
            <tr>
                <th class="p-4">วันที่</th>
                <th class="p-4">เลขที่อ้างอิง</th>
                <th class="p-4">ผู้รับเงิน</th>
                <th class="p-4">เลขประจำตัวผู้เสียภาษี</th>
				<th class="p-4">ใบกำกับภาษี</th>                 
				<th class="p-4 text-right">ยอดจ่าย (ฐาน)</th>
                <th class="p-4 text-right">ภาษีที่หัก</th>
                <th class="p-4 text-center no-print">จัดการ</th>
            </tr>
        </thead>
        <tbody class="divide-y text-slate-700">
            <?php 
            $sum_base = 0; $sum_tax = 0;
            foreach($list as $r): 
                $sum_base += $r['base_amount'];
                $sum_tax += $r['wht_amount'];
            ?>
            <tr class="hover:bg-slate-50">
                <td class="p-4"><?= date('d/m/Y', strtotime($r['doc_date'])) ?></td>
                <td class="p-4 font-bold"><?= $r['doc_no'] ?></td>
                <td class="p-4"><?= $r['name'] ?></td>
				<td class="p-4 font-mono text-sm"><?= htmlspecialchars($r['tax_id']) ?></td>
                <td class="p-4 text-xs text-slate-500"><?= str_replace(',', ', ', $r['inv_nos']) ?></td>
                <td class="p-4 text-right"><?= number_format($r['base_amount'], 2) ?></td>
                <td class="p-4 text-right font-bold text-red-600"><?= number_format($r['wht_amount'], 2) ?></td>
                <td class="p-4 text-center no-print">
                    <a href="?edit_id=<?= $r['id'] ?>&y=<?= $y ?>" class="text-blue-600 font-semibold mr-3 hover:underline">แก้ไข</a>
                    <button onclick="confirmDel(<?= $r['id'] ?>)" class="text-red-400 hover:text-red-600">ลบ</button>
                </td>
            </tr>
            <?php endforeach; ?>
            
            <?php if(count($list) > 0): ?>
            <tr class="bg-slate-100 font-bold">
                <td colspan="5" class="p-4 text-right">รวมยอดประจำปี <?= $y ?> :</td> <td class="p-4 text-right text-blue-700"><?= number_format($sum_base, 2) ?></td>
                <td class="p-4 text-right text-red-700"><?= number_format($sum_tax, 2) ?></td>
                <td class="no-print"></td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


        <div class="no-print mt-10 flex gap-4">
            <button onclick="window.print()" class="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-black">
                <span>🖨️</span> พิมพ์รายงาน
            </button>
            <a href="export_excel_wht.php?y=<?=$y?>" class="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700 transition-all">
                <span>📊</span> ส่งออก Excel
            </a>
        </div>
    </main>

    <div id="modal" class="fixed inset-0 bg-black/50 hidden items-center justify-center p-4 z-50 no-print">
        <div class="bg-white rounded-3xl w-full max-w-lg p-6">
            <h3 class="text-xl font-bold mb-4">เลือกใบกำกับภาษีซื้อ (ปี <?= $y ?>)</h3>
            <div id="inv_list" class="space-y-2 max-h-64 overflow-y-auto mb-6 pr-2 text-sm"></div>
            <div class="flex gap-2">
                <button onclick="addSelected()" class="flex-1 bg-blue-600 text-white py-2 rounded-xl font-bold">ตกลง</button>
                <button onclick="closeModal()" class="flex-1 bg-slate-100 py-2 rounded-xl font-bold">ปิด</button>
            </div>
        </div>
    </div>

    <script>
    function calculateTax() {
        const base = parseFloat(document.getElementById('base_amount').value) || 0;
        const typeSelect = document.getElementById('type_id');
        const rate = parseFloat(typeSelect.options[typeSelect.selectedIndex].getAttribute('data-rate')) || 0;
        const tax = base * rate;
        document.getElementById('wht_amount').value = tax.toFixed(2);
    }

    function fetchInvoices() {
        const sid = document.getElementById('seller_id').value;
        if(!sid) return;
        fetch(`wht_entry.php?fetch_inv=1&sid=${sid}&y=<?= $y ?>`)
            .then(res => res.json())
            .then(data => {
                let html = '';
                data.forEach(i => {
                    html += `
                    <label class="flex items-center gap-3 p-3 border rounded-xl hover:bg-slate-50 cursor-pointer">
                        <input type="checkbox" class="inv-chk w-4 h-4 rounded text-blue-600" value="${i.tax_invoice_no}">
                        <div class="text-sm"><span class="font-bold">${i.tax_invoice_no}</span> <span class="text-slate-400 ml-2">(${i.tax_date})</span></div>
                    </label>`;
                });
                document.getElementById('inv_list').innerHTML = html || '<p class="p-4 text-center">ไม่พบข้อมูลใบกำกับภาษี</p>';
            });
    }

    function openModal() {
        if(!document.getElementById('seller_id').value) {
            Swal.fire({ icon:'warning', text:'กรุณาเลือกผู้รับเงินก่อน' }); return;
        }
        document.getElementById('modal').classList.replace('hidden', 'flex'); 
    }
    
    function closeModal() { document.getElementById('modal').classList.replace('flex', 'hidden'); }

    function addSelected() {
        const container = document.getElementById('selected_inv');
        document.querySelectorAll('.inv-chk:checked').forEach(c => {
            if(!document.querySelector(`input[name="inv_nos[]"][value="${c.value}"]`)) {
                container.innerHTML += `
                <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded-lg flex items-center gap-1 text-sm font-semibold">
                    ${c.value} <input type="hidden" name="inv_nos[]" value="${c.value}">
                    <button type="button" onclick="this.parentElement.remove()" class="text-red-500 ml-1">×</button>
                </span>`;
            }
        });
        closeModal();
    }

    function confirmDel(id) {
        Swal.fire({ title: 'ยืนยันการลบ?', icon: 'warning', showCancelButton: true, confirmButtonText: 'ลบข้อมูล' })
        .then((result) => { if (result.isConfirmed) { location.href = `wht_entry.php?del_id=${id}&y=<?= $y ?>`; } })
    }
    </script>
</body>
</html>