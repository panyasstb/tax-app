<?php
session_start(); require_once '../config/db.php';
if(!isset($_SESSION['user_id'])) header("Location: ../auth/login.php");

$cid = $_SESSION['company_id']; 
$type = $_GET['type'] ?? 'OUTPUT';
$m = $_GET['m'] ?? date('m'); 
$y = $_GET['y'] ?? date('Y'); // ใช้ ค.ศ.
$edit_data = null; $error = '';

if(isset($_GET['edit_id'])){
    $st = $pdo->prepare("SELECT * FROM vat_records WHERE id = ? AND company_id = ?");
    $st->execute([$_GET['edit_id'], $cid]); $edit_data = $st->fetch();
}

if(isset($_GET['del_id'])){
    $pdo->prepare("DELETE FROM vat_records WHERE id = ? AND company_id = ?")->execute([$_GET['del_id'], $cid]);
    header("Location: tax_entry.php?type=$type&m=$m&y=$y"); exit();
}

$c_type = ($type == 'INPUT') ? 'BUYER' : 'SELLER';
$c_stmt = $pdo->prepare("SELECT id, name, tax_id, branch_code FROM contacts WHERE company_id = ? AND type = ? ORDER BY name ASC");
$c_stmt->execute([$cid, $c_type]); 
$contacts = $c_stmt->fetchAll();

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $doc_no = trim($_POST['doc_no']); $rid = $_POST['record_id'] ?? '';
    $chk = $pdo->prepare("SELECT id FROM vat_records WHERE tax_invoice_no=? AND type=? AND company_id=? AND id!=?");
    $chk->execute([$doc_no, $type, $cid, $rid]);
    if($chk->fetch()){ $error = "เลขที่ใบกำกับภาษีนี้มีในระบบแล้ว!"; }
    else {
        if(!empty($rid)){
            $sql = "UPDATE vat_records SET contact_id=?, tax_date=?, tax_invoice_no=?, base_amount=?, vat_amount=?, total_amount=? WHERE id=? AND company_id=?";
            $pdo->prepare($sql)->execute([$_POST['contact_id'], $_POST['tax_date'], $doc_no, $_POST['base'], $_POST['vat'], $_POST['total'], $rid, $cid]);
        } else {
            $sql = "INSERT INTO vat_records (company_id, contact_id, type, tax_date, tax_invoice_no, base_amount, vat_amount, total_amount) VALUES (?,?,?,?,?,?,?,?)";
            $pdo->prepare($sql)->execute([$cid, $_POST['contact_id'], $type, $_POST['tax_date'], $doc_no, $_POST['base'], $_POST['vat'], $_POST['total']]);
        }
        header("Location: tax_entry.php?type=$type&m=$m&y=$y&success=1"); exit();
    }
}

$list_sql = "SELECT v.*, c.name, c.tax_id, c.branch_code 
             FROM vat_records v 
             LEFT JOIN contacts c ON v.contact_id = c.id 
             WHERE v.company_id = ? AND v.type = ? AND MONTH(v.tax_date) = ? AND YEAR(v.tax_date) = ? 
             ORDER BY v.tax_date ASC, v.id ASC";
$st = $pdo->prepare($list_sql);
$st->execute([$cid, $type, $m, $y]);
$list = $st->fetchAll();

$s_base=0; $s_vat=0; foreach($list as $r){ $s_base+=$r['base_amount']; $s_vat+=$r['vat_amount']; }
?>
<!DOCTYPE html>
<html lang="th"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script><script src="https://cdn.jsdelivr.net"></script><title>บันทึกภาษี</title></head>
<body class="flex bg-slate-50 min-h-screen">
<?php include '../includes/sidebar.php'; ?>
<main class="flex-1 p-8">
    <h1 class="text-2xl font-bold mb-4">📝 บันทึกภาษี<?=$type=='OUTPUT'?'ขาย':'ซื้อ'?></h1>
    
    <!-- ฟอร์มเลือกเดือนและปี ค.ศ. -->
    <form method="GET" class="mb-4 flex gap-2 bg-white p-4 rounded-2xl border"><input type="hidden" name="type" value="<?=$type?>">
        <span class="font-bold py-2">เลือก เดือนและปี ภาษี:</span>
        <select name="m" class="border p-2 rounded-xl"><?php for($i=1;$i<=12;$i++){ $val=sprintf('%02d',$i); echo "<option value='$val' ".($m==$val?'selected':'').">$val</option>"; } ?></select>
        <select name="y" class="border p-2 rounded-xl"><?php for($i=date('Y')-2;$i<=date('Y')+1;$i++) echo "<option value='$i' ".($y==$i?'selected':'').">$i</option>"; ?></select>
        <button class="bg-slate-800 text-white px-6 rounded-xl hover:bg-slate-700">เรียกดู</button>
    </form>

    <form method="POST" class="bg-white p-6 rounded-3xl shadow-sm border mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <input type="hidden" name="record_id" value="<?=$edit_data['id']??''?>">
<div class="md:col-span-2 relative"> <label class="block text-sm font-medium text-slate-700 mb-2">ค้นหาชื่อผู้ซื้อ/ผู้ขาย (พิมพ์เพื่อค้นหา)</label>
    
    <input type="text" id="contact_search" 
           class="w-full border-2 border-slate-200 p-4 rounded-2xl focus:border-blue-500 outline-none transition-all" 
           placeholder="พิมพ์ชื่อบริษัท หรือเลขผู้เสียภาษี..." autocomplete="off">
    
    <input type="hidden" name="contact_id" id="contact_id_hidden" value="<?= $edit_data['contact_id'] ?? '' ?>">
    
    <div id="contact_results" 
         class="absolute z-50 w-full left-0 bg-white border-2 border-blue-100 rounded-2xl mt-1 shadow-xl max-h-64 overflow-y-auto hidden">
    </div>
</div>
<script>
// แปลงข้อมูลคู่ค้าจาก PHP เป็น JavaScript Array
const contacts = <?php echo json_encode($contacts); ?>;

const searchInput = document.getElementById('contact_search');
const resultsDiv = document.getElementById('contact_results');
const hiddenInput = document.getElementById('contact_id_hidden');

// ฟังก์ชันค้นหาและแสดงผลแบบเต็มความกว้าง
searchInput.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    if (q.length < 1) {
        resultsDiv.classList.add('hidden');
        return;
    }

    // กรองข้อมูลจากชื่อ หรือ เลขผู้เสียภาษี
    const filtered = contacts.filter(c => 
        c.name.toLowerCase().includes(q) || 
        c.tax_id.includes(q)
    );

    if (filtered.length > 0) {
        resultsDiv.innerHTML = filtered.map(c => `
            <div onclick="selectContact('${c.id}', '${c.name}', '${c.branch_code}')" 
                 class="p-4 hover:bg-blue-50 cursor-pointer border-b border-slate-50 last:border-0 transition-colors">
                <div class="font-bold text-slate-800">${c.name}</div>
                <div class="text-xs text-slate-500 mt-1">
                    เลขประจำตัว: ${c.tax_id} | สาขา: ${c.branch_code == '00000' ? 'สำนักงานใหญ่' : c.branch_code}
                </div>
            </div>
        `).join('');
        resultsDiv.classList.remove('hidden');
    } else {
        resultsDiv.innerHTML = '<div class="p-4 text-sm text-slate-400 italic">ไม่พบข้อมูลคู่ค้า</div>';
        resultsDiv.classList.remove('hidden');
    }
});

// ฟังก์ชันเมื่อคลิกเลือกคู่ค้า
function selectContact(id, name, branch) {
    const branchText = (branch === '00000') ? 'สำนักงานใหญ่' : 'สาขา: ' + branch;
    searchInput.value = `${name} (${branchText})`;
    hiddenInput.value = id;
    resultsDiv.classList.add('hidden');
}

// ปิดกล่องผลลัพธ์เมื่อคลิกที่อื่น
document.addEventListener('click', function(e) {
    if (!searchInput.contains(e.target) && !resultsDiv.contains(e.target)) {
        resultsDiv.classList.add('hidden');
    }
});

// กรณีโหมดแก้ไข: แสดงชื่อเริ่มต้น
<?php if($edit_data): 
    $st_c = $pdo->prepare("SELECT name, branch_code FROM contacts WHERE id = ?");
    $st_c->execute([$edit_data['contact_id']]);
    $curr_c = $st_c->fetch();
    if($curr_c):
        $b_text = ($curr_c['branch_code'] == '00000') ? 'สำนักงานใหญ่' : 'สาขา: ' . $curr_c['branch_code'];
?>
    searchInput.value = "<?= htmlspecialchars($curr_c['name']) ?> (<?= $b_text ?>)";
<?php endif; endif; ?>
</script>


        <input type="date" name="tax_date" value="<?=$edit_data['tax_date']??date('Y-m-d')?>" class="border p-3 rounded-xl mt-5">
        <input type="text" name="doc_no" placeholder="เลขที่ใบกำกับภาษี" value="<?=$edit_data['tax_invoice_no']??''?>" required class="border p-3 rounded-xl mt-5">
        <input type="number" step="0.01" id="base" name="base" placeholder="ราคารวมก่อนภาษีมูลค่าเพิ่ม" value="<?=$edit_data['base_amount']??''?>" class="border p-3 rounded-xl">
        <input type="number" id="vat" name="vat" readonly class="border p-3 rounded-xl bg-blue-50 font-bold text-blue-600" value="<?=$edit_data['vat_amount']??''?>">
        <input type="number" id="total" name="total" readonly class="border p-3 rounded-xl bg-slate-100 font-bold" value="<?=$edit_data['total_amount']??''?>">
        <button class="bg-blue-600 text-white font-bold rounded-xl shadow-lg hover:bg-blue-700 py-3"><?=$edit_data?'อัปเดตข้อมูล':'บันทึกรายการ'?></button>
    </form>

    <div class="grid grid-cols-2 gap-4 mb-6 text-white text-center">
        <div class="bg-slate-900 p-4 rounded-2xl"><p class="text-xs opacity-70 uppercase">ราคารวมก่อนภาษีของเดือน   <?=$m?>    ค.ศ.<?=$y?></p><p class="text-xl font-bold"><?=number_format($s_base,2)?></p></div>
        <div class="bg-blue-600 p-4 rounded-2xl"><p class="text-xs opacity-70 uppercase">ภาษีรวมีของเดือน   <?=$m?>    ค.ศ.<?=$y?></p><p class="text-xl font-bold"><?=number_format($s_vat,2)?></p></div>
    </div>

    <div class="bg-white rounded-3xl shadow-sm border overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-slate-50 text-slate-500 text-sm">
			<tr>
				<th class="p-4">วันที่</th>
				<th class="p-4">เลขที่ใบกำกับภาษี</th>
				<th class="p-4">คู่ค้า</th>
				<th class="p-4">เลขที่ผู้เสียภาษี  (สาขา)</th>
				<th class="p-4 text-right">ราคารวมก่อนภาษี</th>
				<th class="p-4 text-right">VAT 7% </th>
				<th class="p-4 text-center">จัดการ</th>
			</tr>
			</thead>
            <tbody class="divide-y text-slate-700"><?php foreach($list as $r): ?>
			<tr>
				<td class="p-4"><?=date('d/m/Y',strtotime($r['tax_date']))?></td>
				<td class="p-4 font-mono font-medium"><?=$r['tax_invoice_no']?></td>
				<td class="p-4"><?=$r['name']?></td>
				<td class="p-4"><?=htmlspecialchars($r['tax_id'])?> (<?=htmlspecialchars($r['branch_code'])?>)</td>
				<td class="p-4 text-right"><?=number_format($r['base_amount'],2)?></td>
				<td class="p-4 text-right font-bold text-blue-600"><?=number_format($r['vat_amount'],2)?></td>
				<td class="p-4 text-center"><a href="?type=<?=$type?>&m=<?=$m?>&y=<?=$y?>&edit_id=<?=$r['id']?>" class="text-blue-600 mr-3">แก้ไข</a><button onclick="confirmDel(<?=$r['id']?>)" class="text-red-500">ลบ</button></td>
			</tr><?php endforeach; ?>
			</tbody>
        </table>
    </div>
</main>
<script>
document.getElementById('base').oninput=function(){let b=parseFloat(this.value)||0; let v=(b*0.07).toFixed(2); document.getElementById('vat').value=v; document.getElementById('total').value=(b+parseFloat(v)).toFixed(2);};
<?php if(isset($_GET['success'])) echo "Swal.fire({icon:'success',title:'สำเร็จ',toast:true,position:'top-end',showConfirmButton:false,timer:2000});"; ?>
<?php if($error) echo "Swal.fire('ผิดพลาด','$error','error');"; ?>
function confirmDel(id){ Swal.fire({title:'ลบรายการนี้?',icon:'warning',showCancelButton:true,confirmButtonColor:'#d33'}).then((r)=>{if(r.isConfirmed)window.location.href=`tax_entry.php?type=<?=$type?>&m=<?=$m?>&y=<?=$y?>&del_id=${id}`}); }
</script></body></html>
