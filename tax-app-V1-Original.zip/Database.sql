-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2026 at 10:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tax-app`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `company_name`, `tax_id`, `created_at`) VALUES
(1, 'APP Inter Supply', '0203554003831', '2026-02-22 17:43:24');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `type` enum('BUYER','SELLER') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_id` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch_code` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '00000',
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `company_id`, `type`, `name`, `tax_id`, `branch_code`, `address`) VALUES
(1, 1, 'BUYER', 'บริษัท แอดไวซ์ ไอที อินฟินิท จำกัด (มหาชน)', '0107565000620', '00008', 'โครงการอาทาระมอลล์ ห้องเลขที่ 102 ชั้นที่ 1 เลขที่ 222/6 ถนนศรีราชานคร3 ตำบลศรีราชา อำเภอศรีราชา จังหวัดชลบุรี 20110'),
(2, 1, 'BUYER', 'บริษัท ยูนิตี้ ไอที ซิสเต็ม จำกัด', '0125560022747', '00034', '90/64 หมู่ที่4 ตำบลในเมือง อำเภอเมืองขอนแก่น จังหวัดขอนแก่น 40000'),
(3, 1, 'BUYER', 'บริษัท ยูนิตี้ ไอที ซิสเต็ม จำกัด', '0125560022747', '00024', '556 ถนนโพศรี ตำบลหมากแข้ง อำเภอเมืองอุดรธานี จังหวัดอุดรธานี 41000'),
(4, 1, 'BUYER', 'บริษัท เอสไอเอส ดิสทริบิวชั่น (ประเทศไทย) จำกัด', '0107547000052', '00000', '9 อาคารภคินท์ ชั้นที่ 9 ห้องเลขที่ 901 ถนนรัชดาภิเษก แขวงดินแดง เขตดินแดง กรุงเทพมหานคร 10400'),
(5, 1, 'BUYER', 'บริษัท ซีอุส ไอที (ไทยแลนด์) จำกัด', '0105549121688', '00000', '801/224-225 หมู่ที่ 8 ตำบลคูคต อำเภอลำลูกกา จ.ปทุมธานี 12130'),
(6, 1, 'BUYER', 'บริษัท ฮาร์ดแวร์เฮาส์ คอร์ปอเรชั่น จำกัด', '0115565022583', '00008', '1071 หมู่ที่ 7 ตำบลท่าตูม อำเภอศรีมหาโพธิ จังหวัดปราจีนบุรี 25140'),
(7, 1, 'BUYER', 'บริษัท สยามโกลบอลเฮ้าส์ จำกัด', '0107551000029', '00042', '292 หมู่ 6 ตำบลนาอาน อำเภอเมืองเลย จังหวัดเลย '),
(8, 1, 'BUYER', 'บริษัท ไพศาลอิเล็กทรอนิกส์ จำกัด', '0115551006203', '00008', '446/1 ถนนอ่อนนุช แขวงประเวศ เขตประเวศ กรุงเทพมหานคร 10250'),
(9, 1, 'BUYER', 'บริษัท เอ็น.อาร์. เอ็นจิเนียริ่ง จำกัด', '0105560166421', '00001', '120 14 หมู่ที่12 ซอย กิ่งแก้ว 21/2 ตำบลราชาเทวะ อำเภอบางพลี สมุทรปราการ 10540'),
(10, 1, 'BUYER', 'บริษัท คิดพอดี จำกัด', '0505563000325', '00000', '129/112 หมู่ที่ 2 ตำบลต้นเปา อำเภอสันกำแพง จังหวัดเชียงใหม่ 50130'),
(11, 1, 'BUYER', 'บริษัท พีแอนด์ที โฮสติ้ง จำกัด', '0105551128996', '00000', '160/643 ถนนสีลม แขวงสุริยวงศ์ เขตบางรัก กรุงเทพมหานคร 10500'),
(12, 1, 'BUYER', 'บริษัท แอดวานซ์ ไวร์เลส เน็ทเวอร์ค จำกัด', '0105548115897', '00000', ''),
(13, 1, 'BUYER', 'บริษัท เอสพีเค มอร์เตอร์พาร์ทส์ จำกัด', '0105548070524', '00000', ''),
(14, 1, 'BUYER', 'บริษัท เมืองไฟฟ้า จำกัด', '0105547160015', '00000', ''),
(16, 1, 'BUYER', 'บริษัท เนสเซ็น ไอที ซิสเต็ม จำกัด', '\'012556703246', '00000', ''),
(17, 1, 'BUYER', 'บริษัท โฮม โปรดักส์ เซ็นเตอร์ จำกัด', '0107544000043', '00121', ''),
(18, 1, 'BUYER', 'บริษัท เภตรา ซัพพลาย จำกัด', '0745560006550', '00000', ''),
(19, 1, 'BUYER', 'บริษัท โฮม โปรดักส์ เซ็นเตอร์ จำกัด', '0107544000043', '00124', ''),
(20, 1, 'BUYER', 'บริษัท วีนิก กรุ๊ป จำกัด', '0115561000208', '00000', ''),
(21, 1, 'BUYER', 'บริษัท เอบีโกลบอล ซัพพลาย จำกัด', '0525560001461', '00000', ''),
(22, 1, 'BUYER', 'ห้างหุ้นส่วนจำกัด เอ็นพี เทค โซลูชั่น', '0413559001346', '00000', ''),
(23, 1, 'BUYER', 'บริษัท แอดไวซ์ ไอที อินฟินิท จำกัด (มหาชน)', '0107565000620', '00000', ''),
(24, 1, 'BUYER', 'บริษัท แอดไวซ์ ไอที อินฟินิท จำกัด (มหาชน)', '0107565000620', '00026', ''),
(25, 1, 'BUYER', 'บริษัท แซทดิจิตอล จำกัด', '0105568002761', '00000', ''),
(26, 1, 'BUYER', 'บริษัท โฮม โปรดักส์ เซ็นเตอร์ จำกัด', '0107544000043', '00030', ''),
(27, 1, 'BUYER', 'บริษัท เจแอนนด์เจ สลีป โปรดักส์ จำกัด', '0355558000318', '00000', ''),
(28, 1, 'BUYER', 'บริษัท แอลอีอี อินโนเวชั่น จำกัด', '0105561016236', '00000', ''),
(29, 1, 'BUYER', 'บริษัท ซีอาร์ซี ไทวัสดุ จำกัด', '0105555021215', '00071', ''),
(30, 1, 'BUYER', 'บริษัท ฮาร์ดแวร์เฮาส์ คอร์ปอเรชั่น จำกัด', '0115565022583', '00000', ''),
(31, 1, 'BUYER', 'บริษัท เอช ไอ พี โกลบอล จำกัด', '0105548007695', '00000', ''),
(32, 1, 'BUYER', 'บริษัท ฮาร์ดแวร์ คิง จำกัด', '0205560013224', '00000', ''),
(33, 1, 'BUYER', 'บริษัท คอมเซเว่น จำกัด', '0107557000462', '00816', ''),
(34, 1, 'BUYER', 'บริษัท ดอทสยาม จำกัด', '0845557007639', '00001', ''),
(35, 1, 'BUYER', 'บริษัท ดีมีเตอร์ ไอซีที จำกัด', '0105558024720', '00000', ''),
(36, 1, 'BUYER', 'บริษัท ออฟฟิศเมท (ไทย) จำกัด', '0105537143215', '00000', ''),
(37, 1, 'BUYER', 'บริษัท อีซี่ เน็ต จำกัด', '0115555003373', '00000', ''),
(38, 1, 'BUYER', 'Dijital Engineering Center Co., Ltd.', '0115549001526', '00000', ''),
(39, 1, 'BUYER', 'บริษัท อินเตอร์ลิงค์ คอมมิวนิเคชั่น จำกัด', '010754700022', '00000', ''),
(40, 1, 'BUYER', 'บริษัท อินเตอร์ลิงค์ คอมมิวนิเคชั่น จำกัด', '010754700022', '00005', ''),
(41, 1, 'SELLER', 'บริษัท โซโก้ เทค (ไทยแลนด์) จำกัด', '0205566008125', '00000', ''),
(42, 1, 'SELLER', 'บริษัท รวมโชค ร่วมทุนพัฒนา จำกัด', '0205555036157', '00000', ''),
(43, 1, 'SELLER', 'บริษัท รันเนอร์ อินดัสทรี (ประเทศไทย) จำกัด', '0105562073403', '00000', ''),
(44, 1, 'SELLER', 'บริษัท อาร์.วี.เจ. เอ็นจิเนียริ่ง จำกัด', '0115552012924', '00000', ''),
(45, 1, 'SELLER', 'บริษัท อาร์.วี.เจ. เอ็นจิเนียริ่ง จำกัด', '0115552012924', '00002', ''),
(46, 1, 'SELLER', 'บริษัท เอสทีเค อินฟอร์เมชั่น จำกัด', '0115557002277', '00000', ''),
(47, 1, 'SELLER', 'บริษัท มายเพลส พร็อพเพอร์ตี้ กรุ๊ป จำกัด', '0445558000488', '00000', ''),
(48, 1, 'SELLER', 'บริษัท มานีธาดา พร็อพเพอร์ตี้ จำกัด', '0105557063136', '00000', ''),
(49, 1, 'SELLER', 'บริษัท มณีทอง กรุ๊ป จำกัด', '0415566002834', '00000', ''),
(50, 1, 'SELLER', 'บริษัท แอคคอม สยาม จำกัด', '0105552067435', '00000', ''),
(51, 1, 'SELLER', 'บริษัท เดอะ บีเอส บิสโตร จำกัด', '0105567048016', '00000', ''),
(52, 1, 'SELLER', 'HENGYUAN HOME FURNISHING (THAILAND) CO., LTD.', '0205564015230', '00000', ''),
(53, 1, 'SELLER', 'FUDING TECHNOLOGY CO., LTD.', '0215568003163', '00000', ''),
(54, 1, 'SELLER', 'ห้างหุ้นส่วนจำกัด ศิราทรัพย์ ปิโตรเลี่ยม', '0303564001368', '00000', ''),
(55, 1, 'SELLER', 'บริษัท ที.โอ.ไทย จำกัด', '0215548002994', '00000', ''),
(56, 1, 'SELLER', 'บริษัท ยังโฮม นิว แมททีเรียล (ประเทศไทย) จำกัด', '0115567019300', '00000', ''),
(57, 1, 'SELLER', 'บริษัท อ่าวจริง โลจิสติกส์ จำกัด', '0205567010597', '00000', ''),
(58, 1, 'SELLER', 'บริษัท ทีทีพี อินเตอร์ไรท์ จำกัด', '0105549034114', '00000', ''),
(59, 1, 'SELLER', 'Daika Kogyo (Thailand) Co., Ltd.', '0205547017700', '00000', ''),
(60, 1, 'SELLER', 'บริษัท ซีโนเล็คเทคโนโลยี (ไทยแลนด์) จำกัด', '0215566010481', '00000', ''),
(61, 1, 'SELLER', 'บริษัท บราวน์เฮ้าส์โฮเทล จำกัด', '0415555000525', '00000', ''),
(62, 1, 'SELLER', 'บริษัท ทู เอ็ม โลจิสติกส์ จำกัด', '0205568045435', '00000', ''),
(63, 1, 'SELLER', 'บริษัท ดู ดี อินเตอร์เนชั่นแนล (ไทยแลนด์) จำกัด', '0105569189081', '00000', ''),
(64, 1, 'SELLER', 'UNICHOIS TECHNOLOGY (THAILAND) CO., LTD.', '0205567041843', '00000', ''),
(65, 1, 'SELLER', 'บริษัท อินสตอลไดเรค จำกัด', '0115553005620', '00000', ''),
(66, 1, 'SELLER', 'บริษัท วิศวกรรมธรณีและฐานราก จำกัด', '0105536064347', '00000', ''),
(67, 1, 'SELLER', 'บริษัท วีอาร์ เซอร์วิส เน็ตเวิร์ค จำกัด', '0135562027495', '00000', ''),
(68, 1, 'SELLER', 'บริษัท เลคิเซ่ ดีเวลลอปเมนท์ จำกัด', '0745564006490', '00000', ''),
(69, 1, 'SELLER', 'บริษัท เจ พี โมเดิร์นนิตี้ จำกัด', '0105558184531', '00000', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_expire` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `company_id`, `email`, `password`, `full_name`, `reset_token`, `token_expire`) VALUES
(1, 1, 'app@appinter.biz', '$2y$10$488ylw5PwF15ua/5Ed0f/eVKuI5mcPDlLI8Pag/dcLYiMpFiR/PBe', 'PANYA CHIMPA', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vat_records`
--

CREATE TABLE `vat_records` (
  `id` int(11) NOT NULL,
  `company_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `type` enum('INPUT','OUTPUT') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_date` date DEFAULT NULL,
  `tax_invoice_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_amount` decimal(15,2) DEFAULT NULL,
  `vat_amount` decimal(15,2) DEFAULT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `vat_records`
--

INSERT INTO `vat_records` (`id`, `company_id`, `contact_id`, `type`, `tax_date`, `tax_invoice_no`, `base_amount`, `vat_amount`, `total_amount`) VALUES
(1, 1, 19, 'INPUT', '2026-03-03', '118464', 3238.32, 226.68, 3465.00),
(2, 1, 19, 'INPUT', '2026-03-03', '118522', 544.83, 38.14, 582.97),
(3, 1, 19, 'INPUT', '2026-03-03', '118622', 433.33, 30.33, 463.66),
(4, 1, 4, 'INPUT', '2026-03-04', '1414561822', 2375.00, 166.25, 2541.25),
(5, 1, 46, 'OUTPUT', '2026-03-02', 'IV-2026032', 59275.00, 4149.25, 63424.25),
(6, 1, 49, 'OUTPUT', '2026-03-02', 'IV-2026033', 9030.35, 632.12, 9662.47),
(7, 1, 67, 'OUTPUT', '2026-03-02', 'IV-2026034', 17672.00, 1237.04, 18909.04),
(8, 1, 68, 'OUTPUT', '2026-03-02', 'IV-2026035', 3250.00, 227.50, 3477.50),
(9, 1, 68, 'OUTPUT', '2026-03-02', 'IV-2026036', 3250.00, 227.50, 3477.50),
(10, 1, 43, 'OUTPUT', '2026-03-06', 'IV-2026037', 2940.00, 205.80, 3145.80),
(11, 1, 44, 'OUTPUT', '2026-03-05', 'IV-2026038', 17500.00, 1225.00, 18725.00),
(12, 1, 61, 'OUTPUT', '2026-09-03', 'IV-2026039', 25500.00, 1785.00, 27285.00),
(13, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026040', 19043.00, 1333.01, 20376.01),
(14, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026042', 32157.00, 2250.99, 34407.99),
(15, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026043', 12100.00, 847.00, 12947.00),
(16, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026045', 75560.00, 5289.20, 80849.20),
(17, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026044', 53700.00, 3759.00, 57459.00),
(18, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026046', 23300.00, 1631.00, 24931.00),
(19, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026047', 9690.00, 678.30, 10368.30),
(20, 1, 50, 'OUTPUT', '2026-03-09', 'IV-2026048', 2500.00, 175.00, 2675.00),
(21, 1, 69, 'OUTPUT', '2026-03-20', 'IV-2026049', 3700.00, 259.00, 3959.00),
(22, 1, 69, 'OUTPUT', '2026-03-20', 'IV-2026050', 9200.00, 644.00, 9844.00);

-- --------------------------------------------------------

--
-- Table structure for table `wht_rates`
--

CREATE TABLE `wht_rates` (
  `id` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `rate_percent` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wht_rates`
--

INSERT INTO `wht_rates` (`id`, `label`, `rate_percent`) VALUES
(1, 'ค่าบริการ/รับเหมา', 3.00),
(2, 'ค่าขนส่ง', 1.00),
(3, 'ค่าเช่า', 5.00),
(4, 'ค่าโฆษณา', 2.00),
(5, 'จ้างทำของ', 3.00);

-- --------------------------------------------------------

--
-- Table structure for table `wht_records`
--

CREATE TABLE `wht_records` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `doc_date` date NOT NULL,
  `inv_nos` text DEFAULT NULL,
  `doc_no` varchar(50) NOT NULL,
  `income_type` varchar(255) DEFAULT 'ค่าบริการ',
  `wht_rate_id` int(11) NOT NULL,
  `base_amount` decimal(15,2) NOT NULL,
  `wht_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `type_id` int(11) DEFAULT NULL,
  `tax_amount` decimal(15,2) NOT NULL,
  `ref_tax_invoice` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wht_records`
--

INSERT INTO `wht_records` (`id`, `company_id`, `contact_id`, `doc_date`, `inv_nos`, `doc_no`, `income_type`, `wht_rate_id`, `base_amount`, `wht_amount`, `type_id`, `tax_amount`, `ref_tax_invoice`, `created_at`) VALUES
(4, 1, 50, '2026-03-27', 'IV-2026040,IV-2026042', '123', 'ค่าบริการ', 0, 5000.00, 150.00, 1, 0.00, NULL, '2026-03-27 13:04:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tax_id` (`tax_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `vat_records`
--
ALTER TABLE `vat_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- Indexes for table `wht_rates`
--
ALTER TABLE `wht_rates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wht_records`
--
ALTER TABLE `wht_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`),
  ADD KEY `contact_id` (`contact_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vat_records`
--
ALTER TABLE `vat_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `wht_rates`
--
ALTER TABLE `wht_rates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wht_records`
--
ALTER TABLE `wht_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vat_records`
--
ALTER TABLE `vat_records`
  ADD CONSTRAINT `vat_records_ibfk_1` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
