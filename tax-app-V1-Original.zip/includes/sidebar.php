<aside class="w-64 bg-slate-900 text-slate-300 h-screen sticky top-0 flex flex-col p-5 no-print">
    <div class="text-2xl font-bold text-white mb-10 flex items-center gap-2"><div class="w-8 h-8 bg-blue-500 rounded-lg"></div> TAX-PRO </div>
    <nav class="flex-1 space-y-4">
        <p class="text-slate-500 text-[15px] font-bold uppercase">📁 ข้อมูลพื้นฐาน</p>
        <a href="/tax-app/modules/contacts.php?type=BUYER" class="block p-2 hover:bg-slate-800 rounded-lg">จัดการผู้ซื้อ</a>
        <a href="/tax-app/modules/contacts.php?type=SELLER" class="block p-2 hover:bg-slate-800 rounded-lg">จัดการผู้ขาย</a>
        <p class="text-slate-500 text-[15px] font-bold uppercase mt-4">📝 บันทึกภาษี </p>
        <a href="/tax-app/modules/tax_entry.php?type=OUTPUT" class="block p-2 hover:bg-slate-800 rounded-xl">📤 บันทึกภาษีขาย<br>(เลือกผู้ขาย)</a>
		<a href="/tax-app/modules/tax_entry.php?type=INPUT" class="block p-2 hover:bg-slate-800 rounded-xl">📥 บันทึกภาษีซื้อ<br>(เลือกผู้ซื้อ)</a>
        <p class="text-slate-500 text-[15px] font-bold uppercase mt-4">📊 รายงาน</p>
        <a href="/tax-app/modules/reports.php" class="block p-2 hover:bg-slate-800 rounded-lg">สรุป ภ.พ.30</a>

<p class="text-slate-500 text-[15px] font-bold uppercase mt-4">📄 ภาษีหัก ณ ที่จ่าย</p>
<a href="/tax-app/modules/wht_entry.php" class="block p-2 hover:bg-slate-800 rounded-xl">✍️ บันทึก หัก ณ ที่จ่าย</a>


    </nav>
    <div class="pt-4 border-t border-slate-800"><a href="/tax-app/logout.php" class="text-red-400 p-2 block">🔒 ออกจากระบบ</a></div>
	<div class="pt-4 border-t border-slate-800"><a href="https://www.appinter.co.th target="_blank " class="text-red-400 p-2 block"> 
    <p>&copy; 2026 By APP Inter Supply. All Rights Reserved. Ver.1</p> </a></div>
</aside>
<script src="https://cdn.jsdelivr.net"></script>
