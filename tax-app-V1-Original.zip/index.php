<?php
session_start(); require_once 'config/db.php';
if(!isset($_SESSION['user_id'])) header("Location: auth/login.php");
$cid = $_SESSION['company_id']; $y = date('Y');

$chart_sql = "SELECT MONTH(tax_date) as m, 
    SUM(CASE WHEN type='OUTPUT' THEN vat_amount ELSE 0 END) as out_v,
    SUM(CASE WHEN type='INPUT' THEN vat_amount ELSE 0 END) as in_v 
    FROM vat_records WHERE company_id = ? AND YEAR(tax_date) = ? GROUP BY MONTH(tax_date)";
$st = $pdo->prepare($chart_sql); $st->execute([$cid, $y]);
$data = $st->fetchAll();
$out_v = array_fill(1, 12, 0); $in_v = array_fill(1, 12, 0);
foreach($data as $r){ $out_v[$r['m']] = $r['out_v']; $in_v[$r['m']] = $r['in_v']; }
?>
<!DOCTYPE html>
<html lang="th"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script><script src="https://cdn.jsdelivr.net"></script></head>
<body class="flex bg-slate-50 min-h-screen">
<?php include 'includes/sidebar.php'; ?>
<main class="flex-1 p-8">
    <h1 class="text-3xl font-bold mb-6">สรุปผลประกอบการรายปี <?= $y+543 ?></h1>
    <div class="bg-white p-8 rounded-[2rem] shadow-sm border">
        <canvas id="yearlyChart" height="100"></canvas>
    </div>
</main>
<script>
new Chart(document.getElementById('yearlyChart'), {
    type: 'bar',
    data: {
        labels: ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'],
        datasets: [
            { label: 'ภาษีขาย', data: <?= json_encode(array_values($out_v)) ?>, backgroundColor: '#10b981' },
            { label: 'ภาษีซื้อ', data: <?= json_encode(array_values($in_v)) ?>, backgroundColor: '#3b82f6' }
        ]
    }
});
</script></body></html>
