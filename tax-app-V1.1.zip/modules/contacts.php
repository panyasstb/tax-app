<?php
session_start();
require_once '../config/db.php';

// 1. ตรวจสอบการ Login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

$cid = $_SESSION['company_id'];
$type = isset($_GET['type']) ? $_GET['type'] : 'BUYER';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// 2. ดึงข้อมูลคู่ค้า พร้อมระบบ Search
// ใช้ COALESCE หรือการดึงข้อมูลตรงๆ เพื่อป้องกัน Error หากไม่ได้รัน SQL ALTER TABLE
$sql = "SELECT * FROM contacts WHERE company_id = ? AND type = ?";
$params = [$cid, $type];

if ($search !== '') {
    $sql .= " AND (name LIKE ? OR tax_id LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY name ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>จัดการคู่ค้า | TAX-PRO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Kanit', sans-serif; background-color: #f1f5f9; }
        /* ซ่อน scrollbar สำหรับ Chrome, Safari และ Opera */
        body::-webkit-scrollbar { display: none; }
        body { -ms-overflow-style: none;  scrollbar-width: none; }
    </style>
</head>
<body class="h-screen flex overflow-hidden">

    <?php include '../includes/sidebar.php'; ?>

    <main class="flex-1 flex flex-col h-full overflow-hidden p-4 md:p-8 w-full">
        
        <div class="max-w-7xl mx-auto w-full flex flex-col h-full gap-6">
            
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
                <div class="flex items-center gap-3">
                    <button id="mobile-menu-btn" class="md:hidden bg-white p-2 rounded-xl shadow-sm border text-slate-600">☰</button>
                    <div>
                        <h1 class="text-2xl md:text-3xl font-bold text-slate-800">จัดการ<?= $type == 'BUYER' ? 'ผู้ซื้อ (Vender)' : 'ผู้ขาย (Customer)' ?></h1>
                        <p class="text-slate-500 text-sm">ค้นหาและแก้ไขข้อมูลคู่ค้าในระบบ</p>
                    </div>
                </div>

                <div class="flex flex-col md:flex-row gap-3 w-full md:w-auto">
                    <form method="GET" class="relative">
                        <input type="hidden" name="type" value="<?= $type ?>">
                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" 
                               placeholder="ค้นหาชื่อ หรือ เลขผู้เสียภาษี..." 
                               class="pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none w-full md:w-80 transition-all shadow-sm">
                        <span class="absolute left-4 top-3.5 text-slate-400">🔍</span>
                    </form>

                    <a href="contact_add.php?type=<?= $type ?>" class="bg-indigo-600 text-white px-6 py-3 rounded-2xl font-bold shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all text-center">
                        + เพิ่มใหม่
                    </a>
                </div>
            </div>

            <div class="flex p-1 bg-slate-200 rounded-2xl w-fit shrink-0">
                <a href="?type=BUYER" class="px-8 py-2 rounded-xl text-sm font-bold transition-all <?= $type == 'BUYER' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700' ?>">
                    🛒 ผู้ซื้อ
                </a>
                <a href="?type=SELLER" class="px-8 py-2 rounded-xl text-sm font-bold transition-all <?= $type == 'SELLER' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700' ?>">
                    🚚 ผู้ขาย
                </a>
            </div>

            <div class="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 flex-1 overflow-hidden flex flex-col">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-slate-50/50">
                                <th class="p-4 text-slate-400 font-bold text-xs uppercase tracking-wider">ชื่อคู่ค้า / บริษัท</th>
                                <th class="p-4 text-slate-400 font-bold text-xs uppercase tracking-wider">เลขผู้เสียภาษี (สาขา)</th>
								<th class="p-4 text-slate-400 font-bold text-xs uppercase tracking-wider">ที่อยู่</th>
                                <th class="p-4 text-slate-400 font-bold text-xs uppercase tracking-wider text-right">จัดการ</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-50">
                            <?php if (count($contacts) > 0): ?>
                                <?php foreach ($contacts as $row): ?>
                                <tr class="hover:bg-slate-50/50 transition-colors">
                                    <td class="p-1">
                                        <div class="font-bold text-slate-700"><?= htmlspecialchars($row['name']) ?></div>
                                    </td>
                                    <td class="p-1">
                                        <div class="font-mono text-slate-600"><?= htmlspecialchars($row['tax_id'] ?? '') ?> 
                                        
                                           (<?= htmlspecialchars($row['branch_code'] ?? '') ?>)
                                        </div>
                                    </td>
									<td>
										<div class="text-xs text-slate-400 md:hidden mt-1"><?= htmlspecialchars($row['address']) ?></div>
									</td>
                                    <td class="p-1 text-right space-x-1">
                                        <a href="contact_edit.php?id=<?= $row['id'] ?>&type=<?= $type ?>" 
                                           class="inline-flex p-2.5 bg-amber-50 text-amber-600 rounded-xl hover:bg-amber-100 transition-colors" title="แก้ไข">
                                            ✏️
                                        </a>
                                        <button onclick="confirmDelete(<?= $row['id'] ?>, '<?= $type ?>')" 
                                                class="inline-flex p-2.5 bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-100 transition-colors" title="ลบ">
                                            🗑️
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="p-20 text-center text-slate-300 italic">
                                        ไม่พบข้อมูลที่ค้นหา...
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script>
        // ยืนยันการลบด้วย SweetAlert2
        function confirmDelete(id, type) {
            Swal.fire({
                title: 'ต้องการลบข้อมูล?',
                text: "การลบจะไม่สามารถกู้คืนข้อมูลได้!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e11d48',
                cancelButtonColor: '#94a3b8',
                confirmButtonText: 'ยืนยันการลบ',
                cancelButtonText: 'ยกเลิก',
                borderRadius: '1.5rem'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `contact_delete.php?id=${id}&type=${type}`;
                }
            })
        }

        // แจ้งเตือนสถานะต่างๆ
        const params = new URLSearchParams(window.location.search);
        if (params.get('status') === 'added') {
            Swal.fire({ icon: 'success', title: 'เพิ่มข้อมูลสำเร็จ', showConfirmButton: false, timer: 1500 });
        } else if (params.get('status') === 'updated') {
            Swal.fire({ icon: 'success', title: 'อัปเดตข้อมูลสำเร็จ', showConfirmButton: false, timer: 1500 });
        } else if (params.get('status') === 'deleted') {
            Swal.fire({ icon: 'success', title: 'ลบข้อมูลเรียบร้อย', showConfirmButton: false, timer: 1500 });
        } else if (params.get('error') === 'in_use') {
            Swal.fire({ icon: 'error', title: 'ไม่สามารถลบได้', text: 'คูค้านี้ถูกใช้งานในรายการภาษีแล้ว' });
        }

        // ปุ่มเมนูสำหรับมือถือ
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('-translate-x-full');
        });
    </script>
</body>
</html>