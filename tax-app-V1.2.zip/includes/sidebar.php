<?php
// ตรวจสอบว่าไฟล์ที่เรียกใช้อยู่ลึกแค่ไหน (เพื่อปรับ path กลับไปที่ root)
$current_dir = dirname($_SERVER['PHP_SELF']);
$base_path = (strpos($current_dir, 'modules') !== false || strpos($current_dir, 'auth') !== false) ? '../' : '';
?>
<div id="sidebar" class="bg-white h-screen w-64 fixed md:relative p-6 flex flex-col border-r border-slate-100 z-50
                      transition-transform duration-300 ease-in-out
                      -translate-x-full md:translate-x-0 shadow-xl md:shadow-none">

    <div class="flex justify-between items-center mb-10 shrink-0">
        <h1 class="text-2xl font-bold text-indigo-600">TAX-PRO</h1>
        
        <button id="close-sidebar-btn" class="md:hidden text-slate-400 hover:text-rose-500 text-xl">
            ✕
        </button>
    </div>

    <nav class="flex-1 space-y-2 overflow-y-auto">

        <a href="<?= $base_path ?>index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 text-indigo-600 font-bold">
            📊 Dashboard
		</a>
	  <p class="text-slate-500 text-[15px] font-bold uppercase">📁 ข้อมูลพื้นฐาน</p>
        <a href="<?= $base_path ?>modules/contacts.php?type=BUYER" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 text-indigo-600 font-bold">
            📝จัดการผู้ซื้อ
        </a>
        <a href="<?= $base_path ?>modules/contacts.php?type=SELLER" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 text-indigo-600 font-bold">
            📝จัดการผู้ขาย
        </a>
      <p class="text-slate-500 text-[15px] font-bold uppercase mt-4">📝 บันทึกภาษี </p>
        <a href="<?= $base_path ?>modules/tax_entry.php?type=OUTPUT" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 text-indigo-600 font-bold">
            📥บันทึกภาษีขาย<br>(เลือกผู้ขาย)
        </a>
        <a href="<?= $base_path ?>modules/tax_entry.php?type=INPUT" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 text-indigo-600 font-bold">
            📥บันทึกภาษีซื้อ<br>(เลือกผู้ซื้อ)
        </a>
     <p class="text-slate-500 text-[15px] font-bold uppercase mt-4">📊 รายงาน</p>
        <a href="<?= $base_path ?>modules/reports.php" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 text-indigo-600 font-bold">
            🧾สรุป ภ.พ.30
        </a>
	<p class="text-slate-500 text-[15px] font-bold uppercase mt-4">📄 ภาษีหัก ณ ที่จ่าย</p>
        <a href="<?= $base_path ?>modules/wht_entry.php" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-indigo-50 text-indigo-600 font-bold">
            ✍️บันทึก หัก ณ ที่จ่าย
        </a>
		

        </nav>

    <div class="mt-auto shrink-0 border-t pt-4">
        <a href="<?= $base_path ?>auth/logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-rose-500 hover:bg-rose-50">
            🚪 ออกจากระบบ
        </a>


	<p class="text-slate-500 text-[15px] font-bold uppercase mt-4">&copy; Ver.1</p>
	</div>

</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const closeSidebarBtn = document.getElementById('close-sidebar-btn');
        const sidebar = document.getElementById('sidebar');
        
        if (closeSidebarBtn && sidebar) {
            closeSidebarBtn.addEventListener('click', function() {
                // ซ่อน Sidebar กลับไปทางซ้าย
                sidebar.classList.add('-translate-x-full');
                sidebar.classList.remove('translate-x-0');
            });
        }
    });
</script>