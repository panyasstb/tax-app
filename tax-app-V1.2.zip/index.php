﻿<?php
session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}

$cid = $_SESSION['company_id'];
$year = isset($_GET['y']) ? intval($_GET['y']) : date('Y');

// ดึงข้อมูลสำหรับกราฟ
$sql = "SELECT 
            MONTH(tax_date) as m, 
            SUM(CASE WHEN type = 'OUTPUT' THEN base_amount ELSE 0 END) as sell_base,
            SUM(CASE WHEN type = 'INPUT' THEN base_amount ELSE 0 END) as buy_base
        FROM vat_records 
        WHERE company_id = ? AND YEAR(tax_date) = ?
        GROUP BY MONTH(tax_date)
        ORDER BY m ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$cid, $year]);
$chart_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sell_monthly = array_fill(1, 12, 0);
$buy_monthly = array_fill(1, 12, 0);
foreach ($chart_data as $row) {
    $sell_monthly[$row['m']] = (float)$row['sell_base'];
    $buy_monthly[$row['m']] = (float)$row['buy_base'];
}

$total_sell = array_sum($sell_monthly);
$total_buy = array_sum($buy_monthly);
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | TAX-PRO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Kanit', sans-serif; background-color: #f1f5f9; }
        /* ซ่อน Scrollbar ของหน้าต่างหลัก */
        body::-webkit-scrollbar { display: none; }
        body { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body class="h-screen flex overflow-hidden relative"> <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 flex flex-col h-full overflow-hidden p-4 md:p-8 w-full md:w-auto">
        
        <div class="max-w-7xl mx-auto w-full flex flex-col h-full gap-4 md:gap-6">
            
            <div class="flex flex-row justify-between items-center shrink-0 gap-2">
                <div class="flex items-center gap-3">
                    <button id="mobile-menu-btn" class="md:hidden bg-white p-2 rounded-xl shadow-sm border text-slate-600">
                        ☰
                    </button>
                    <div>
                        <h1 class="text-xl md:text-3xl font-bold text-slate-800">ภาพรวมระบบ</h1>
                        <p class="text-slate-500 text-xs md:text-sm hidden md:block">สรุปสถิติรายได้และค่าใช้จ่ายประจำปี <?= $year ?></p>
                    </div>
                </div>
                
                <form method="GET" class="bg-white px-3 py-1.5 md:px-4 md:py-2 rounded-2xl shadow-sm border border-slate-200 shrink-0">
                    <select name="y" onchange="this.form.submit()" class="bg-transparent border-none outline-none font-semibold text-indigo-600 cursor-pointer text-sm md:text-base">
                        <?php for($i=date('Y'); $i>=date('Y')-5; $i--): ?>
                            <option value="<?= $i ?>" <?= $year == $i ? 'selected' : '' ?>>ปี ค.ศ. <?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </form>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 shrink-0">
                <div class="bg-white p-4 md:p-6 rounded-3xl md:rounded-[2rem] shadow-sm border-t-4 border-emerald-500">
                    <p class="text-slate-400 text-[10px] md:text-xs font-bold uppercase">รายได้รวม</p>
                    <h3 class="text-xl md:text-2xl font-bold text-slate-800 mt-0.5">฿<?= number_format($total_sell, 2) ?></h3>
                </div>
                <div class="bg-white p-4 md:p-6 rounded-3xl md:rounded-[2rem] shadow-sm border-t-4 border-rose-500">
                    <p class="text-slate-400 text-[10px] md:text-xs font-bold uppercase">ค่าใช้จ่ายรวม</p>
                    <h3 class="text-xl md:text-2xl font-bold text-slate-800 mt-0.5">฿<?= number_format($total_buy, 2) ?></h3>
                </div>
                <div class="bg-white p-4 md:p-6 rounded-3xl md:rounded-[2rem] shadow-sm border-t-4 border-indigo-600">
                    <p class="text-slate-400 text-[10px] md:text-xs font-bold uppercase">กำไรขั้นต้น</p>
                    <h3 class="text-xl md:text-2xl font-bold text-indigo-600 mt-0.5">฿<?= number_format($total_sell - $total_buy, 2) ?></h3>
                </div>
            </div>

            <div class="bg-white p-4 md:p-6 rounded-3xl md:rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col flex-1 min-h-0 relative">
                <div class="flex items-center justify-between mb-4 md:mb-6 shrink-0 gap-2">
                    <h2 class="font-bold text-slate-700 text-sm md:text-base">แนวโน้มรายเดือน</h2>
                    <div class="flex gap-3 md:gap-4 shrink-0">
                        <span class="text-[10px] md:text-xs flex items-center gap-1.5"><i class="w-2 h-2 md:w-3 md:h-3 bg-emerald-500 rounded-full"></i> รายได้</span>
                        <span class="text-[10px] md:text-xs flex items-center gap-1.5"><i class="w-2 h-2 md:w-3 md:h-3 bg-rose-400 rounded-full"></i> รายจ่าย</span>
                    </div>
                </div>
                <div class="flex-1 min-h-0 relative">
                    <canvas id="taxChart"></canvas>
                </div>
            </div>

        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const sidebar = document.getElementById('sidebar'); // ต้องแน่ใจว่าใน sidebar.php มี id="sidebar"
            
            if (mobileMenuBtn && sidebar) {
                mobileMenuBtn.addEventListener('click', function() {
                    // เปลี่ยนสถานะการซ่อน/แสดง Sidebar บนมือถือ
                    sidebar.classList.toggle('-translate-x-full');
                    sidebar.classList.toggle('translate-x-0');
                });
            }
        });
    </script>

    <script>
        // ... (โค้ด Chart.js เดิม) ...
        const ctx = document.getElementById('taxChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.', 'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'],
                datasets: [
                    {
                        label: 'รายได้',
                        data: <?= json_encode(array_values($sell_monthly)) ?>,
                        backgroundColor: '#10b981',
                        borderRadius: 6, // ลดรัศมีลงหน่อยให้เหมาะกับมือถือ
                        barThickness: 'flex',
                        maxBarThickness: 15 // ลดขนาดแท่งลงหน่อย
                    },
                    {
                        label: 'รายจ่าย',
                        data: <?= json_encode(array_values($buy_monthly)) ?>,
                        backgroundColor: '#fb7185',
                        borderRadius: 6,
                        barThickness: 'flex',
                        maxBarThickness: 15
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { 
                        beginAtZero: true, 
                        grid: { color: '#f1f5f9' },
                        ticks: { 
                            font: { family: 'Kanit', size: 10 }, // ลดขนาดตัวอักษรแกน Y
                            callback: function(value) {
                                // แสดงผลย่อบนมือถือ เช่น 10k แทน 10,000
                                if (value >= 1000) return '฿' + (value/1000).toFixed(1) + 'k';
                                return '฿' + value;
                            }
                        }
                    },
                    x: { 
                        grid: { display: false }, 
                        ticks: { font: { family: 'Kanit', size: 10 } } // ลดขนาดตัวอักษรแกน X
                    }
                }
            }
        });
    </script>
</body>
</html>