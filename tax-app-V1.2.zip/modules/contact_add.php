﻿<?php
session_start();
require_once '../config/db.php';

$type = $_GET['type'] ?? 'BUYER';
$cid = $_SESSION['company_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tax_id = trim($_POST['tax_id']);
    $branch = trim($_POST['branch_code']);

    // --- ตรวจสอบข้อมูลซ้ำ ---
    $check = $pdo->prepare("SELECT id FROM contacts WHERE tax_id = ? AND branch_code = ? AND company_id = ?");
    $check->execute([$tax_id, $branch, $cid]);
    
    if ($check->fetch()) {
        $error = "ขออภัย! คู่ค้าเลขที่เสียภาษี $tax_id สาขา $branch นี้มีอยู่ในระบบแล้ว";
    } else {
        $stmt = $pdo->prepare("INSERT INTO contacts (company_id, name, tax_id, branch_code, address, type) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$cid, $_POST['name'], $tax_id, $branch, $_POST['address'], $type]);
        header("Location: contacts.php?type=$type&status=added");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เพิ่มคู่ค้า | TAX-PRO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;600&display=swap" rel="stylesheet">
    <style>body { font-family: 'Kanit', sans-serif; background-color: #f1f5f9; }</style>
</head>
<body class="h-screen flex overflow-hidden">
    <?php include '../includes/sidebar.php'; ?>
    <main class="flex-1 flex flex-col h-full overflow-hidden p-4 md:p-8 w-full">
        <div class="max-w-3xl mx-auto w-full flex flex-col h-full gap-6">
            <div class="flex items-center gap-4 shrink-0">
                <a href="contacts.php?type=<?= $type ?>" class="bg-white p-3 rounded-2xl shadow-sm border">← กลับ</a>
                <h1 class="text-2xl font-bold">เพิ่ม<?= $type == 'BUYER' ? 'ผู้ซื้อ' : 'ผู้ขาย' ?></h1>
            </div>

            <div class="bg-white p-8 rounded-[2.5rem] shadow-sm border overflow-y-auto">
                <form method="POST" class="space-y-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="space-y-2">
                            <label class="text-sm font-bold text-slate-600">เลขผู้เสียภาษี (13 หลัก)</label>
                            <input type="text" name="tax_id" required maxlength="13" placeholder="0123456789012" class="w-full p-4 bg-slate-50 border rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-mono">
                        </div>
                        <div class="space-y-2">
                            <label class="text-sm font-bold text-slate-600">รหัสสาขา (เช่น 00000 คือสำนักงานใหญ่)</label>
                            <input type="text" name="branch_code" required maxlength="5" value="00000" class="w-full p-4 bg-slate-50 border rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-mono">
                        </div>
                    </div>
                    <div class="space-y-2">
                        <label class="text-sm font-bold text-slate-600">ชื่อคู่ค้า / บริษัท</label>
                        <input type="text" name="name" required class="w-full p-4 bg-slate-50 border rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div class="space-y-2">
                        <label class="text-sm font-bold text-slate-600">ที่อยู่ตามจดทะเบียน</label>
                        <textarea name="address" required rows="3" class="w-full p-4 bg-slate-50 border rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>
                    <button type="submit" class="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg hover:bg-indigo-700 transition-all">💾 บันทึกข้อมูล</button>
                </form>
            </div>
        </div>
    </main>

    <?php if($error): ?>
    <script>Swal.fire({ icon: 'warning', title: 'พบข้อมูลซ้ำ!', text: '<?= $error ?>', confirmButtonColor: '#4f46e5' });</script>
    <?php endif; ?>
</body>
</html>