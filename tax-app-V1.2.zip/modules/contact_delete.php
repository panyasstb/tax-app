﻿<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: contacts.php");
    exit;
}

$id = $_GET['id'];
$type = $_GET['type'];
$company_id = $_SESSION['company_id'];

try {
    // ลบเฉพาะข้อมูลที่เป็นของบริษัทตัวเองเท่านั้น
    $stmt = $pdo->prepare("DELETE FROM contacts WHERE id = ? AND company_id = ?");
    $stmt->execute([$id, $company_id]);

    if ($stmt->rowCount() > 0) {
        header("Location: contacts.php?type=$type&status=deleted");
    } else {
        header("Location: contacts.php?type=$type&error=notfound");
    }
} catch (PDOException $e) {
    // ถ้าลบไม่ได้เพราะติด Foreign Key (ถูกใช้ใน vat_records)
    if ($e->getCode() == '23000') {
        header("Location: contacts.php?type=$type&error=in_use");
    } else {
        header("Location: contacts.php?type=$type&error=db_error");
    }
}