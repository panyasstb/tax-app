﻿<?php
session_start();
require_once '../config/db.php';

$id = $_GET['id'] ?? null;
$type = $_GET['type'] ?? 'BUYER';
$cid = $_SESSION['company_id'];

// ดึงข้อมูลเดิม
$stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = ? AND company_id = ?");
$stmt->execute([$id, $cid]);
$contact = $stmt->fetch();

if (!$contact) { header("Location: contacts.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("UPDATE contacts SET name=?, tax_id=?, branch_code=?, address=? WHERE id=? AND company_id=?");
    $stmt->execute([$_POST['name'], $_POST['tax_id'], $_POST['branch_code'], $_POST['address'], $id, $cid]);
    header("Location: contacts.php?type=$type&status=updated");
    exit;
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Kanit&display=swap" rel="stylesheet">
</head>
<body class="bg-slate-50 font-['Kanit'] p-8">
    <div class="max-w-xl mx-auto bg-white p-8 rounded-[2.5rem] shadow-sm border">
        <h1 class="text-2xl font-bold mb-6 text-slate-800">แก้ไขข้อมูลคู่ค้า</h1>
        <form method="POST" class="space-y-4">
            <input type="text" name="name" value="<?= $contact['name'] ?>" placeholder="ชื่อบริษัท" required class="w-full p-4 bg-slate-50 border rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500">
            <div class="flex gap-4">
                <input type="text" name="tax_id" value="<?= $contact['tax_id'] ?>" placeholder="เลขผู้เสียภาษี" maxlength="13" class="flex-1 p-4 bg-slate-50 border rounded-2xl outline-none font-mono">
                <input type="text" name="branch_code" value="<?= $contact['branch_code'] ?>" placeholder="สาขา" maxlength="5" class="w-32 p-4 bg-slate-50 border rounded-2xl outline-none font-mono text-center">
            </div>
            <textarea name="address" rows="3" class="w-full p-4 bg-slate-50 border rounded-2xl outline-none"><?= $contact['address'] ?></textarea>
            <div class="flex gap-3">
                <button class="flex-1 bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg">💾 บันทึกการแก้ไข</button>
                <a href="contacts.php?type=<?= $type ?>" class="flex-1 bg-slate-100 text-slate-600 py-4 rounded-2xl font-bold text-center">ยกเลิก</a>
            </div>
        </form>
    </div>
</body>
</html>