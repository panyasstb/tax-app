<?php
session_start(); require_once '../config/db.php';
if(!isset($_SESSION['user_id'])) header("Location: ../auth/login.php");

$cid = $_SESSION['company_id'];
$sel_m = $_GET['m'] ?? ''; 
$sel_y = $_GET['y'] ?? ''; 
$view_type = $_GET['view'] ?? 'OUTPUT'; // ค่าเริ่มต้นเป็นภาษีขาย

$res = null; $show_report = false;

if (!empty($sel_m) && !empty($sel_y)) {
    $show_report = true;
    // 1. สรุปยอดรวม (ดึงทั้ง In/Out มาคำนวณ Net VAT)
    $sql_sum = "SELECT 
        SUM(CASE WHEN type='OUTPUT' THEN base_amount ELSE 0 END) as out_b,
        SUM(CASE WHEN type='OUTPUT' THEN vat_amount ELSE 0 END) as out_v,
        SUM(CASE WHEN type='INPUT' THEN base_amount ELSE 0 END) as in_b,
        SUM(CASE WHEN type='INPUT' THEN vat_amount ELSE 0 END) as in_v 
        FROM vat_records WHERE company_id = ? AND MONTH(tax_date) = ? AND YEAR(tax_date) = ?";
    $st_sum = $pdo->prepare($sql_sum);
    $st_sum->execute([$cid, $sel_m, $sel_y]);
    $res = $st_sum->fetch();

    // 2. ดึงรายการตามประเภทที่เลือก (INPUT หรือ OUTPUT)

    $sql_list = "SELECT v.*, c.name, c.tax_id, c.branch_code FROM vat_records v JOIN contacts c ON v.contact_id=c.id 
                 WHERE v.company_id=? AND v.type=? AND MONTH(v.tax_date)=? AND YEAR(v.tax_date)=? 
                 ORDER BY v.tax_date ASC";
    $stmt_list = $pdo->prepare($sql_list);
    $stmt_list->execute([$cid, $view_type, $sel_m, $sel_y]);
    $records = $stmt_list->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="th"><head><meta charset="UTF-8"><script src="https://cdn.tailwindcss.com"></script><title>รายงานภาษีมูลค่าเพิ่ม</title>
<style>
    @media print {
        @page { size: A4; margin: 1cm; }
        .no-print { display: none !important; }
        body { background: white; zoom: 70%; padding: 0;  }
        main { padding: 0 !important; width: 100%; }
        .report-container { border: none !important; box-shadow: none !important; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table th, table td { border: 1px solid #333 !important; padding: 8px !important; font-size: 12px; }
        thead { display: table-header-group; }
    }
</style>
</head>
<body class="flex bg-slate-50 min-h-screen">
<?php include '../includes/sidebar.php'; ?>
<main class="flex-1 p-10">
    <h1 class="text-2xl font-bold mb-6 text-slate-800">📊 รายงานสรุปภาษีมูลค่าเพิ่ม (ภ.พ.30)</h1>

    <!-- ส่วนกรองข้อมูล (Filter & Type Selector) -->
    <div class="bg-white p-6 rounded-3xl shadow-sm border mb-8 no-print">
        <form method="GET" class="flex flex-wrap items-end gap-4">
            <div class="flex-1 min-w-[150px]">
                <label class="block text-xs font-bold text-slate-500 mb-1 uppercase">เดือนภาษี</label>
                <select name="m" required class="w-full border p-3 rounded-xl bg-slate-50 outline-none">
                    <option value="">-- เลือกเดือน --</option>
                    <?php for($i=1;$i<=12;$i++){ $val=sprintf('%02d',$i); echo "<option value='$val' ".($sel_m==$val?'selected':'').">$val</option>"; } ?>
                </select>
            </div>
            <div class="flex-1 min-w-[150px]">
                <label class="block text-xs font-bold text-slate-500 mb-1 uppercase">ปี ค.ศ.</label>
                <select name="y" required class="w-full border p-3 rounded-xl bg-slate-50 outline-none">
                    <option value="">-- เลือกปี --</option>
                    <?php for($i=date('Y')-2;$i<=date('Y')+1;$i++) echo "<option value='$i' ".($sel_y==$i?'selected':'').">$i</option>"; ?>
                </select>
            </div>
            <div class="flex-1 min-w-[200px]">
                <label class="block text-xs font-bold text-slate-500 mb-1 uppercase">ประเภทรายงาน</label>
                <div class="flex bg-slate-100 p-1 rounded-xl">
                    <button type="button" onclick="setType('OUTPUT')" id="btn-out" class="flex-1 py-2 rounded-lg font-bold text-sm <?= $view_type=='OUTPUT' ? 'bg-white shadow text-emerald-600' : 'text-slate-500' ?>">รายการขายสินค้า</button>
                    <button type="button" onclick="setType('INPUT')" id="btn-in" class="flex-1 py-2 rounded-lg font-bold text-sm <?= $view_type=='INPUT' ? 'bg-white shadow text-blue-600' : 'text-slate-500' ?>">รายการซื้อสินค้า</button>
                    <input type="hidden" name="view" id="view_type" value="<?=$view_type?>">
                </div>
            </div>
            <button type="submit" class="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-800 transition">แสดงรายงาน</button>
        </form>
    </div>

    <?php if($show_report): $net = $res['out_v'] - $res['in_v']; ?>
        <!-- สรุปยอดนำส่งสุทธิ (แสดงเสมอ) -->
        <div class="bg-white p-6 rounded-3xl shadow-sm border-l-8 border-orange-500 mb-8 flex justify-between items-center">
            <div>
                <p class="text-slate-600 font-bold uppercase">สรุปยอดประจำงวด <?=$sel_m?>/<?=$sel_y?></p>
                <h2 class="text-xl font-bold text-slate-500"><?=($net >= 0 ? 'ภาษีที่ต้องชำระเพิ่ม':'ภาษีชำระเกิน (ยกไป)' )?></h2>
            </div>
            <p class="text-2xl font-black text-orange-600">฿ <?=number_format(abs($net), 2)?></p>
        </div>

        <!-- ตารางแสดงรายการตามที่เลือก -->
        <div class="bg-white rounded-3xl shadow-sm border overflow-hidden">
            <div class="p-4 flex justify-between items-center <?= $view_type=='OUTPUT' ? 'bg-emerald-600' : 'bg-blue-600' ?> text-white font-bold">
			<p class="text-2xl font-text-400">
                <span>รายการภาษี<?= $view_type=='OUTPUT' ? 'ขาย ' : 'ซื้อ ' ?></span>
			</p>
                <span>รวมทั้งหมดราคาก่อนภาษี: <?=number_format($view_type=='OUTPUT' ? $res['out_b'] : $res['in_b'], 2)?> | รวมภาษี: <?=number_format($view_type=='OUTPUT' ? $res['out_v'] : $res['in_v'], 2)?></span>
            </div>
            <table class="w-full text-sm text-left">
                <thead class="bg-slate-50"><tr class="border-b"><th class="p-4">วันที่</th><th>เลขที่ใบกำกับภาษี</th><th><?= $view_type=='OUTPUT' ? 'ผู้ซื้อ' : 'ผู้ขาย' ?></th><th class="p-4">เลขที่ผู้เสียภาษี  (สาขา)</th><th class="text-right">ราคารวมก่อนภาษี</th><th class="text-right p-4">ภาษี (7%)</th></tr></thead>
                <tbody class="divide-y">
                    <?php if(empty($records)): ?>
                        <tr><td colspan="5" class="p-10 text-center text-slate-400 italic">-- ไม่พบข้อมูลรายการในหมวดนี้ --</td></tr>
                    <?php else: foreach($records as $r): ?>
                        <tr><td class="p-4"><?=date('d/m/Y', strtotime($r['tax_date']))?></td><td class="font-mono"><?=$r['tax_invoice_no']?></td><td><?=$r['name']?></td>
						
<td class="p-4"><?=htmlspecialchars($r['tax_id'])?> (<?=htmlspecialchars($r['branch_code'])?>)</td>
<td class="text-right"><?=number_format($r['base_amount'],2)?></td><td class="text-right p-4 font-bold <?= $view_type=='OUTPUT' ? 'text-emerald-600' : 'text-blue-600' ?>"><?=number_format($r['vat_amount'],2)?></td></tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <div class="no-print mt-10 flex gap-4">
            <button onclick="window.print()" class="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold">🖨️ พิมพ์</button>
            <a href="export_excel.php?m=<?=$sel_m?>&y=<?=$sel_y?>&view=<?=$view_type?>" class="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold text-center">📊 ส่งออก Excel</a>
        </div>
    <?php else: ?>
        <div class="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-300 text-slate-400 italic">กรุณาเลือกเดือน ปี และประเภทรายงานเพื่อแสดงข้อมูล</div>
    <?php endif; ?>
</main>

<script>
    function setType(type) {
        document.getElementById('view_type').value = type;
        document.getElementById('btn-out').className = type === 'OUTPUT' ? 'flex-1 py-2 rounded-lg font-bold text-sm bg-white shadow text-emerald-600' : 'flex-1 py-2 rounded-lg font-bold text-sm text-slate-500';
        document.getElementById('btn-in').className = type === 'INPUT' ? 'flex-1 py-2 rounded-lg font-bold text-sm bg-white shadow text-blue-600' : 'flex-1 py-2 rounded-lg font-bold text-sm text-slate-500';
    }
</script>
</body></html>
