﻿<?php
session_start();
require_once '../config/db.php';

if(!isset($_SESSION['user_id'])) exit;

$cid = $_SESSION['company_id'];
$m = $_GET['m'] ?? date('m');
$y = $_GET['y'] ?? date('Y');
$view = $_GET['view'] ?? 'OUTPUT';
$filename = "Tax_Report_".$view."_".$m."_".$y.".xls";

$sql = "SELECT v.tax_date, v.tax_invoice_no, c.name, c.tax_id, c.branch_code, v.base_amount, v.vat_amount 
        FROM vat_records v 
        JOIN contacts c ON v.contact_id = c.id 
        WHERE v.company_id = ? AND v.type = ? AND MONTH(v.tax_date) = ? AND YEAR(v.tax_date) = ?";
$st = $pdo->prepare($sql);
$st->execute([$cid, $view, $m, $y]);
$data = $st->fetchAll();

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");

// ใส่ BOM สำหรับ UTF-8 เพื่อให้ภาษาไทยไม่เพี้ยน
$title = ($view == 'OUTPUT') ? "รายการภาษีขาย (Output VAT)" : "รายการภาษีซื้อ (Input VAT)";
$col_name = ($view == 'OUTPUT') ? "ชื่อผู้ซื้อสินค้า/ผู้รับบริการ" : "ชื่อผู้ขายสินค้า/ผู้ให้บริการ";

echo "\xEF\xBB\xBF"; // UTF-8 BOM
?>
<table border="1">
    <tr>
        <th colspan="7" style="font-size: 20px; font-weight: bold;"><?= $title ?></th>
    </tr>
    <tr>
        <th colspan="7">ประจำเดือน <?= $m ?> ปี <?= $y ?></th>
    </tr>
    <tr style="background-color: #eeeeee;">
        <th>วันที่</th>
        <th>เลขที่ใบกำกับ</th>
        <th><?= $col_name ?></th>
        <th>เลขประจำตัวผู้เสียภาษี</th>
        <th>สาขา</th>
        <th>มูลค่าสินค้า</th>
        <th>ภาษีมูลค่าเพิ่ม</th>
    </tr>
    <?php foreach($data as $r): ?>
    <tr>
        <td><?= date('d/m/Y', strtotime($r['tax_date'])) ?></td>
        <td><?= $r['tax_invoice_no'] ?></td>
        <td><?= htmlspecialchars($r['name']) ?></td>
        <td style="mso-number-format:'\@';">'<?= $r['tax_id'] ?></td>
        <td style="mso-number-format:'\@';"><?= str_pad($r['branch_code'], 5, "0", STR_PAD_LEFT) ?></td>
        <td align="right"><?= number_format($r['base_amount'], 2) ?></td>
        <td align="right"><?= number_format($r['vat_amount'], 2) ?></td>
    </tr>
    <?php endforeach; ?>
</table>