﻿<?php
session_start();
require_once '../config/db.php';
$y = $_GET['y'] ?? date('Y');
$cid = $_SESSION['company_id'];

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=WHT_Report_$y.xls");
echo "\xEF\xBB\xBF"; // UTF-8 BOM

$sql = "SELECT w.*, c.name, c.tax_id, c.branch_code FROM wht_records w 
        JOIN contacts c ON w.contact_id = c.id 
        WHERE w.company_id = ? AND YEAR(w.doc_date) = ? ORDER BY w.doc_no ASC";
$st = $pdo->prepare($sql);
$st->execute([$cid, $y]);
$data = $st->fetchAll();
?>
<table border="1">
    <tr style="background:#333; color:white;">
        <th>เลขที่เอกสาร</th>
        <th>วันที่หัก</th>
        <th>ชื่อผู้รับเงิน</th>
        <th>เลขที่ผู้เสียภาษี</th>
        <th>อ้างอิงใบกำกับ</th>
        <th>ยอดเงินต้น</th>
        <th>ภาษีที่หัก</th>
    </tr>
    <?php foreach($data as $r): ?>
    <tr>
        <td><?= $r['doc_no'] ?></td>
        <td><?= date('d/m/Y', strtotime($r['doc_date'])) ?></td>
        <td><?= $r['name'] ?></td>
        <td>'<?= $r['tax_id'] ?> (<?= $r['branch_code'] ?>)</td>
        <td><?= $r['inv_nos'] ?></td>
        <td align="right"><?= number_format($r['base_amount'], 2) ?></td>
        <td align="right"><?= number_format($r['tax_amount'], 2) ?></td>
    </tr>
    <?php endforeach; ?>
</table>